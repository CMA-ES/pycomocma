#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from distutils.core import setup
setup(name='comocma',
      version='1.0',
      py_modules=['como', 'hv', 'moarchiving', 'nondominatedarchive', 'sofomore_logger', 'cma'],
      )

